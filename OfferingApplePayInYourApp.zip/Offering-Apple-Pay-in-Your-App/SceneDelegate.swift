/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Main scene delegate
*/
import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

}

