/*
See LICENSE folder for this sample’s licensing information.

Abstract:
WatchKit extension delegate
*/

import WatchKit

class ExtensionDelegate: NSObject, WKExtensionDelegate {

    func applicationDidFinishLaunching() {
        // Perform any final initialization of your application.
    }

}
